/*  Ring  */
/*  Print your name, and a paragraph describing how your program works */


// make sure your code is clear and easy to follow 

#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

/* describe every method */
int main(int argc, char ** argv)
{
  // comment important lines of code
  printf("Hi, I am %d\n",getpid());
}
