#!/bin/bash

echo Hi I am ring_time.sh
